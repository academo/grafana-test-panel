/* [create-plugin] version: 4.16.2 */
define(["@emotion/css","@grafana/data","@grafana/runtime","@grafana/ui","module","react"],((e,t,r,a,n,o)=>(()=>{"use strict";var s={89:t=>{t.exports=e},781:e=>{e.exports=t},531:e=>{e.exports=r},7:e=>{e.exports=a},308:e=>{e.exports=n},959:e=>{e.exports=o}},i={};function l(e){var t=i[e];if(void 0!==t)return t.exports;var r=i[e]={exports:{}};return s[e](r,r.exports,l),r.exports}l.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return l.d(t,{a:t}),t},l.d=(e,t)=>{for(var r in t)l.o(t,r)&&!l.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},l.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),l.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},l.p="public/plugins/academo-test-panel/";var u={};l.r(u),l.d(u,{CustomEditor:()=>b,plugin:()=>E});var d=l(308),p=l.n(d);l.p=p()&&p().uri?p().uri.slice(0,p().uri.lastIndexOf("/")+1):"public/plugins/academo-test-panel/";var c=l(781),m=l(959),g=l.n(m),f=l(89),v=l(7),x=l(531);const h=()=>({wrapper:f.css`
      font-family: Open Sans;
      position: relative;
    `,svg:f.css`
      position: absolute;
      top: 0;
      left: 0;
    `,textBox:f.css`
      position: absolute;
      bottom: 0;
      left: 0;
      padding: 10px;
    `}),w="default value",E=new c.PanelPlugin((({options:e,data:t,width:r,height:a,fieldConfig:n,id:o})=>{const s=(0,v.useTheme2)(),i=(0,v.useStyles2)(h);return 0===t.series.length?g().createElement(x.PanelDataErrorView,{fieldConfig:n,panelId:o,data:t,needsStringField:!0}):g().createElement("div",{className:(0,f.cx)(i.wrapper,f.css`
          width: ${r}px;
          height: ${a}px;
        `)},g().createElement("svg",{className:i.svg,width:r,height:a,xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink",viewBox:`-${r/2} -${a/2} ${r} ${a}`},g().createElement("g",null,g().createElement("circle",{"data-testid":"simple-panel-circle",style:{fill:s.colors.primary.main},r:100}))),g().createElement("div",{className:i.textBox},e.showSeriesCount&&g().createElement("div",{"data-testid":"simple-panel-series-counter"},"Number of series: ",t.series.length),g().createElement("div",null,"Text option value: ",e.text)))})).setPanelOptions((e=>e.addBooleanSwitch({path:"showSeriesCount",name:"Show series counter",defaultValue:!0}).addCustomEditor({id:"customEditor",path:"customEditor",name:"My custom editor",editor:b,defaultValue:w}))),b=e=>{const t=e.context.options,r=e.value,a=e.onChange;return(0,m.useEffect)((()=>{t.showSeriesCount||r===w||a(w)}),[t,r,a]),g().createElement("div",null,g().createElement(v.Input,{value:r,onChange:e=>a(e.currentTarget.value)}))};return u})()));
//# sourceMappingURL=module.js.map